<html>
 <head>
  <title>Hello World!Test</title>
 </head>
 <body>
 <?php echo '<b>Hello World! I am:</b>'; ?> 
 <?php echo  php_uname('n'); ?>
 </body>
</html>
